from django.contrib import admin
from django.urls import path
from django.conf.urls.static import static
from django.conf import settings 
from store import views


urlpatterns = [
    path('admin/', admin.site.urls),
    path("category/",views.category),
    path("customer/",views.customer),
    path("orderitem/",views.orderItem),
    path("order/",views.order),
    path("shipping/",views.shippingAddress),
    path("products/",views.products),



]+static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)


