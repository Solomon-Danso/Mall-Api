from django.shortcuts import render
from .models import Category,Customer,Products,Order,OrderItem,ShippingAddress
from .serializer import CategorySerializer,CustomerSerializer,ProductsSerializer,OrderSerializer,OrderItemSerializer,ShippingAddressSerializer
from django.http import JsonResponse
from rest_framework.decorators import api_view
from rest_framework.response import Response
from rest_framework import status


@api_view(['GET',"POST"])
def category(request):
    if request.method == "GET":
        category_list = Category.objects.all()
        serializer = CategorySerializer(category_list, many=True)
        return Response(serializer.data)
    if request.method == "POST":
       serializer = CategorySerializer(data = request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data,status=status.HTTP_201_CREATED)




@api_view(['GET',"POST"])
def customer(request):
    if request.method == "GET":
        customer_list = Customer.objects.all()
        serializer = CustomerSerializer(customer_list, many=True)
        return Response(serializer.data)
    if request.method == "POST":
       serializer = CustomerSerializer(data = request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data,status=status.HTTP_201_CREATED)

@api_view(['GET',"POST"])
def orderItem(request):
    if request.method == "GET":
        orderItem_list = orderItem.objects.all()
        serializer = OrderItemSerializer(orderItem_list, many=True)
        return Response(serializer.data)
    if request.method == "POST":
       serializer = OrderItemSerializer(data = request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data,status=status.HTTP_201_CREATED)

@api_view(['GET',"POST"])
def order(request):
    if request.method == "GET":
        order_list = Order.objects.all()
        serializer = OrderSerializer(order_list, many=True)
        return Response(serializer.data)
    if request.method == "POST":
       serializer = OrderSerializer(data = request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data,status=status.HTTP_201_CREATED)

@api_view(['GET',"POST"])
def shippingAddress(request):
    if request.method == "GET":
        shippingAddress_list = ShippingAddress.objects.all()
        serializer = ShippingAddressSerializer(shippingAddress_list, many=True)
        return Response(serializer.data)
    if request.method == "POST":
       serializer = ShippingAddressSerializer(data = request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data,status=status.HTTP_201_CREATED)

@api_view(['GET',"POST"])
def products(request):
    if request.method == "GET":
        products_list = Products.objects.all()
        serializer = ProductsSerializer(products_list, many=True)
        return Response(serializer.data)
    if request.method == "POST":
       serializer = ProductsSerializer(data = request.data)
    if serializer.is_valid():
        serializer.save()
    return Response(serializer.data,status=status.HTTP_201_CREATED)




