from django.db import models
from django.contrib.auth.models import User



class Category(models.Model):
    name = models.CharField(max_length=1000, db_index=True)
    slug = models.SlugField(max_length=1000, unique=True)
    
    class Meta:
        verbose_name_plural = "Categories"

    def __str__(self):
        return self.name


class Customer(models.Model):
   user = models.ForeignKey(User, on_delete=models.CASCADE)
   name = models.CharField(max_length=200)
   email = models.CharField(max_length=100)
   class Meta:
        verbose_name_plural = "Customers"

   def __str__(self):
      return self.name

class Products(models.Model):
    category = models.ForeignKey(Category, on_delete=models.CASCADE, related_name="product")    
    created_by = models.ForeignKey(User, related_name="product_creator",on_delete=models.CASCADE)
    title = models.CharField(max_length=1000)
    author = models.CharField(max_length=1000, default='Admin')
    description = models.TextField(blank=True)
    image = models.FileField(upload_to="uploads/")
    slug = models.SlugField(max_length=1000)
    price = models.DecimalField(max_digits=6,decimal_places=2)
    instock = models.BooleanField(default=True)
    isactive = models.BooleanField(default=True)
    created = models.DateTimeField(auto_now_add=True)
    updated = models.DateTimeField(auto_now=True)

    class Meta:
        verbose_name_plural = "Products"
        ordering = ('-created',)


    def __str__(self):
        return self.title
    
class Order(models.Model):
    customer = models.ForeignKey(Customer, on_delete=models.CASCADE)
    date_ordered = models.DateTimeField(auto_now_add=True)
    complete = models.BooleanField(default=False,null=True, blank=False)
    transaction_id = models.CharField(max_length=200)

    class Meta:
        verbose_name_plural = "Orders"
        ordering = ('-date_ordered',)
    def __str__(self):
        return self.transaction_id


class OrderItem(models.Model):
    product = models.ForeignKey(Products,on_delete=models.SET_NULL,blank=True,null=True)
    order = models.ForeignKey(Order,on_delete=models.SET_NULL,blank=True,null=True)
    quantity = models.IntegerField(default=0, null=True,blank=True)
    date_added = models.DateTimeField(auto_now_add=True)
    class Meta:
        verbose_name_plural = "Order Items"
    def __str__(self):
        return self.order



class ShippingAddress(models.Model):
    customer = models.ForeignKey(Customer,on_delete=models.SET_NULL,null=True)
    order = models.ForeignKey(Order,on_delete=models.SET_NULL,null=True)
    address = models.CharField(max_length=2000)
    city = models.CharField(max_length=100)
    contact = models.CharField(max_length=100)
    date_added = models.DateTimeField(auto_now_add=True)

    class Meta:
        verbose_name_plural = "Shipping Addresses"
    def __str__(self):
        return self.contact